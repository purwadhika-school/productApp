import { ViewPropTypes } from "react-native";
import InteractionManager from './interactionManager'

export { InteractionManager, ViewPropTypes }
